#include "common/task_system/terminal_progress_bar_display.h"

#include "common/assert.h"

namespace lbug {
namespace common {

void TerminalProgressBarDisplay::updateProgress(uint64_t /*queryID*/, double newPipelineProgress,
    uint32_t newNumPipelinesFinished) {
    DASSERT(0.0 <= newPipelineProgress && newPipelineProgress <= 1.0);

    // There can still be data races as the comparison + update of cur/old progress is not done
    // atomically
    // However this error does not build up over time and we don't require perfect progress bar
    // accuracy
    // So we implement it this way with atomics (instead of mutexes) for better performance
    uint32_t curPipelineProgress = (uint32_t)(newPipelineProgress * 100.0);
    uint32_t oldPipelineProgress = (uint32_t)(pipelineProgress * 100.0);
    if (curPipelineProgress > oldPipelineProgress ||
        newNumPipelinesFinished > numPipelinesFinished) {
        pipelineProgress.store(newPipelineProgress);
        numPipelinesFinished.store(newNumPipelinesFinished);
        // R's console API is not thread-safe. Keep progress state without
        // writing from LadybugDB worker threads.
    }
}

void TerminalProgressBarDisplay::finishProgress(uint64_t /*queryID*/) {
    printing = false;
    numPipelines = 0;
    numPipelinesFinished = 0;
    pipelineProgress = 0;
}

void TerminalProgressBarDisplay::printProgressBar() {
    // Intentionally empty for R: native worker threads must not write to the
    // R console, stdout, or stderr.
}

} // namespace common
} // namespace lbug
